//
//  sendEmail_bridge.h
//  mail
//
//  Created by Bob on 2018-11-26.
//  Copyright © 2018 Bob. All rights reserved.
//

#ifndef sendEmail_bridge_h
#define sendEmail_bridge_h
#import <MailCore/MailCore.h>
#import <MailCore/MCOConstants.h>
#endif /* sendEmail_bridge_h */
