//
//  TrackerInfoViewController.swift
//  MindSafe
//
//  Created by Mihai Lapuste on 2018-11-14.
//  Copyright © 2018 Mihai Lapuste. All rights reserved.
//

import UIKit

class TrackerInfoViewController: UIViewController {

    @IBAction func goBackButton(_ sender: Any) {
        // dismiss view once notifcation is scheduled
        dismiss(animated: true, completion: nil) // use if using modal transition
        
    }
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
