//
//  ProgressInfoViewController.swift
//  MindSafe
//
//  Created by Mihai Lapuste on 2018-12-01.
//  Copyright © 2018 Mihai Lapuste. All rights reserved.
//

import UIKit

class ProgressInfoViewController: UIViewController {

    @IBAction func cancelInfo(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
