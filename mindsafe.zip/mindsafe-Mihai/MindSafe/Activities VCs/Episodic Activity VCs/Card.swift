//
//  Card.swift
//  MindSafe
//
//  Created by Mihai Lapuste on 2018-11-28.
//  Copyright © 2018 Mihai Lapuste. All rights reserved.
//

import Foundation

class Card {
    
    var imageName = ""
    var isFlipped = false
    var isMatched = false
    
    
    
}
